package defaultpackage;

public enum Enum {
		A,B,C,D
}
