package defaultpackage;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

public class Class5 
{
	public static void main(String[] args)
	{
		List<Map<String,Integer>> list=new ArrayList<>();
		
		TreeMap<String,Integer>map1=new TreeMap<>();
		map1.put("new Bean(1, 1.0f, 1, Enum.A)", 1);
		map1.put("new Bean(2, 2.0f, 2, Enum.B)", 10);
		map1.put("new Bean(3, 3.0f, 3, Enum.C)", 100);
		map1.put("new Bean(4, 4.0f, 4, Enum.D)", 1000);
		
		
		HashMap<String,Integer>map3=new HashMap<>();
		map3.put("new Bean(1, 1.0f, 1, Enum.A)", 3);
		map3.put("new Bean(2, 2.0f, 2, Enum.B)", 30);
		map3.put("new Bean(3, 3.0f, 3, Enum.C)", 300);
		map3.put("new Bean(4, 4.0f, 4, Enum.D)", 3000);
		
		LinkedHashMap<String,Integer>map2=new LinkedHashMap<>();
		map2.put("new Bean(1, 1.0f, 1, Enum.A)", 2);
		map2.put("new Bean(2, 2.0f, 2, Enum.B)", 20);
		map2.put("new Bean(3, 3.0f, 3, Enum.C)", 200);
		map2.put("new Bean(4, 4.0f, 4, Enum.D)", 2000);
		
	
		list.add(map1);
		list.add(map3);
		list.add(map2);
		System.out.println(list);
		Collections.sort(list,new Comparator<Map<String,Integer>>()
				{
					@Override
					public int compare(Map<String, Integer> o1,
							Map<String, Integer> o2)
					{
						System.out.println(o1.entrySet().iterator().next().getValue()+" "+o2.entrySet().iterator().next().getValue());
						return o1.entrySet().iterator().next().getValue().compareTo(o2.entrySet().iterator().next().getValue());
					}
				});
		System.out.println(list);
	}


}
