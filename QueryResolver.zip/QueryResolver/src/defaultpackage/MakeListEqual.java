package defaultpackage;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class MakeListEqual 
{
	public static void main(String[] args) 
	{
		ArrayList<Been> l1=new ArrayList<>();
		Map<ArrayList<Been>,Integer> l2=new HashMap<ArrayList<Been>,Integer>();
		l1.add(new Been(1, 2.1f, "3", Enum.A));
		l1.add(new Been(1, 2.5f, "3", Enum.A ));
		l1.add(new Been(1, 2.0f, "3", Enum.B));
		l1.add(new Been(1, 2.4f, "3", Enum.B));
		System.out.println(l1);
		Collections.sort(l1);
		System.out.println(l1);
	}
}
