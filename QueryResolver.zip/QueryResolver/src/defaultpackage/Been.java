package defaultpackage;

public class Been implements Comparable<Been>
{
	int a;
	float b;
	String c;
	Enum e;
	

	
	public Been()
	{
		super();
	}

	public Been(int a, float b, String c, Enum e) 
	{
		super();
		this.a = a;
		this.b = b;
		this.c = c;
		this.e = e;
	}

	@Override
	public String toString() {
		return "Bean [a=" + a + ", b=" + b + ", c=" + c + ", e=" + e + "]";
	}

	
	

	/*@Override
	public int compareTo(Been o) {
		
		return this.e.compareTo(o.e);
	}*/
	
	@Override
	public int compareTo(Been o) 
	{
		int i= this.a-o.a;
		if(i!=0)
		 return i;
		i=this.e.compareTo(o.e);
		if(i!=0)
			return i;
		i=this.c.compareTo(o.c);
		return i;
	}
	
	/*@Override
	public int compareTo(Been o) {
		
		return (int)(this.b-o.b);
	}*/
	
	/*@Override
	public int compareTo(Been o) {
		
		return this.a-o.a;
	}*/


	
}
