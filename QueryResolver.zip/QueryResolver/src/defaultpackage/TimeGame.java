package defaultpackage;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Scanner;

public class TimeGame
{
	public static void main(String[] args) throws ParseException 
	{
		Scanner sc=new Scanner(System.in);
		String s=sc.next();
		GregorianCalendar gc= new GregorianCalendar();
		SimpleDateFormat sdf=new SimpleDateFormat("dd-yyyy-M");
		gc.setTime(sdf.parse(s));
		System.out.println(gc.getTime());
		for(int i=1;i<=50;i++)
		{
			gc.set(Calendar.DATE,gc.get(Calendar.DATE)+1);
			if(gc.get(Calendar.DAY_OF_WEEK)==Calendar.SATURDAY  || gc.get(Calendar.DAY_OF_WEEK)==Calendar.SUNDAY)
			{
				System.out.println(gc.getTime());
				System.out.println(gc.get(Calendar.DAY_OF_MONTH)+"-"+(gc.get(Calendar.MONTH)+1));
			}
			
		}
		List<String> l=new ArrayList<String>();
		l.add("a");
		l.add("z");
		l.add("m");
		System.out.println(l);
		Collections.sort(l,new Comparator<String>()
				{

					@Override
					public int compare(String o1, String o2) {
						// TODO Auto-generated method stub
						return o2.compareTo(o1);
					}
				});
		System.out.println(l);
	}
}
