package defaultpackage;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.TreeMap;
import java.util.TreeSet;

public class Class3 
{
	public static void main(String[] args)
	{
		//List
		
		ArrayList<Bean> l1=new ArrayList<Bean>();
		l1.add(new Bean(1, 1.0f, "1", Enum.A));
		l1.add(new Bean(2, 2.0f, "2", Enum.B));
		l1.add(new Bean(3, 3.0f, "3", Enum.C));
		l1.add(new Bean(4, 4.0f, "4", Enum.D));
		//Collections.sort(l1);
		
		LinkedList<Bean> l2=new LinkedList<Bean>();
		l2.add(new Bean(1, 1.0f, "1", Enum.A));
		l2.add(new Bean(2, 2.0f, "2", Enum.B));
		l2.add(new Bean(3, 3.0f, "3", Enum.C));
		l2.add(new Bean(4, 4.0f, "4", Enum.D));
		//Collections.sort(l2); 
		
		//Set
		
		HashSet<Bean>h1=new HashSet<Bean>();
		h1.add(new Bean(1, 1.0f, "1", Enum.A));
		h1.add(new Bean(2, 2.0f, "2", Enum.B));
		h1.add(new Bean(3, 3.0f, "3", Enum.C));
		h1.add(new Bean(4, 4.0f, "4", Enum.D));
		
		//You can't sort HashSet directly.
		//If still you want to sort HashSet then give this reference to List(any of its child) or TreeSet and
		//(remember if it is non-primitive class then the class should implement Comparable or you have to 
		//define Comparator explicitly)
		//Then call Collection.sort on List and again give back the reference of List to LinkedhashSet
		//TreeSet will sort automatically in natural order and you can give back the reference to LinkedHashSet
		
		LinkedHashSet<Bean>h2=new LinkedHashSet<>();
		h2.add(new Bean(1, 1.0f, "1", Enum.A));
		h2.add(new Bean(2, 2.0f, "2", Enum.B));
		h2.add(new Bean(3, 3.0f, "3", Enum.C));
		h2.add(new Bean(4, 4.0f, "4", Enum.D));
		
		
		TreeSet<Bean>h3=new TreeSet<>();
		h3.add(new Bean(1, 1.0f, "1", Enum.A));
		h3.add(new Bean(2, 2.0f, "2", Enum.B));
		h3.add(new Bean(3, 3.0f, "3", Enum.C));
		h3.add(new Bean(4, 4.0f, "4", Enum.D));
		//To make any object valid for TreeSet its class should implement Comparable or we can define our Comparator
		
		//Map
		
		HashMap<Bean,Integer>m1=new HashMap<>();
		m1.put(new Bean(1, 1.0f, "1", Enum.A), 1);
		m1.put(new Bean(2, 2.0f, "2", Enum.B), 2);
		m1.put(new Bean(3, 3.0f, "3", Enum.C), 3);
		m1.put(new Bean(4, 4.0f, "4", Enum.D), 4);
		
		LinkedHashMap<Bean,Integer>m2=new LinkedHashMap<>();
		m2.put(new Bean(1, 1.0f, "1", Enum.A), 1);
		m2.put(new Bean(2, 2.0f, "2", Enum.B), 2);
		m2.put(new Bean(3, 3.0f, "3", Enum.C), 3);
		m2.put(new Bean(4, 4.0f, "4", Enum.D), 4);
		
		
		TreeMap<Bean,Integer>m3=new TreeMap<>();
		m3.put(new Bean(1, 1.0f, "1", Enum.A), 1);
		m3.put(new Bean(2, 2.0f, "2", Enum.B), 2);
		m3.put(new Bean(3, 3.0f, "3", Enum.C), 3);
		m3.put(new Bean(4, 4.0f, "4", Enum.D), 4);
	}
}
