package defaultpackage;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.TreeSet;

public class Class4 
{
	public static void main(String[] args) 
	{
/*		ArrayList<Been> l1=new ArrayList<>();
		l1.add(new Been(3, 3.0f, "3", Enum.C));
		l1.add(new Been(1, 1.0f, "1", Enum.A ));
		l1.add(new Been(4, 4.0f, "4", Enum.D));
		l1.add(new Been(2, 2.0f, "2", Enum.B));
		System.out.println(l1);

		Collections.sort(l1,new Comparator<Been>()
				{
			@Override
			public int compare(Been o1, Been o2)
			{
				return o1.c.compareTo(o2.c);
			}
				});
		System.out.println(l1);

		TreeSet<Been> t1=new TreeSet<>();
		t1.add(new Been(3, 3.0f, "3", Enum.C));
		t1.add(new Been(1, 1.0f, "1", Enum.A ));
		t1.add(new Been(4, 4.0f, "4", Enum.D));
		t1.add(new Been(2, 2.0f, "2", Enum.B));
		System.out.println(t1);
		TreeSet<Been> t2=new TreeSet<>(Collections.reverseOrder());
		t2.add(new Been(3, 3.0f, "3", Enum.C));
		t2.add(new Been(1, 1.0f, "1", Enum.A ));
		t2.add(new Been(4, 4.0f, "4", Enum.D));
		t2.add(new Been(2, 2.0f, "2", Enum.B));
		System.out.println(t2);*/
		
		
		HashMap<Been,Integer>m1=new HashMap<>();
		m1.put(new Been(1, 1.0f, "1", Enum.A), 4);
		m1.put(new Been(2, 2.0f, "2", Enum.B), 3);
		m1.put(new Been(3, 3.0f, "3", Enum.C), 2);
		m1.put(new Been(4, 4.0f, "4", Enum.D), 1);
		System.out.println(m1);
		//Sorting the HashMap
		List<Entry<Been,Integer>> lst=new ArrayList<>(m1.entrySet());
		Collections.sort(lst, new Comparator<Entry<Been,Integer>>()
				{
					@Override
					public int compare(Entry<Been, Integer> o1,
							Entry<Been, Integer> o2) 
					{
						return o1.getValue().compareTo(o2.getValue());
					}
				});
		LinkedHashMap<Been, Integer> lhm= new LinkedHashMap<Been, Integer>();
		for (Entry<Been, Integer> entry : lst) 
			lhm.put(entry.getKey(), entry.getValue());
		System.out.println("after sorting ...........\n"+lhm);
	}
}
